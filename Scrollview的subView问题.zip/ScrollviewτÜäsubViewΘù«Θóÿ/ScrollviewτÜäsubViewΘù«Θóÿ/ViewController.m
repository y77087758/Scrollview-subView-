//
//  ViewController.m
//  Scrollview的subView问题
//
//  Created by yjj on 16/8/3.
//  Copyright © 2016年 yan. All rights reserved.
//

#import "ViewController.h"

#define iPhoneWidth self.view.bounds.size.width
#define iPhoneHeight self.view.bounds.size.height

@interface ViewController ()
/** 滚动视图 */
@property (nonatomic,strong)UIScrollView *scrollView;
/** 颜色 */
@property (nonatomic,strong)NSArray *colors;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    CGFloat scrollViewX = 0;
    CGFloat scrollViewY = 0;
    CGFloat scrollViewW = iPhoneWidth;
    CGFloat scrollViewH = iPhoneHeight/4;
    _scrollView = [[UIScrollView alloc]initWithFrame:(CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH))];
    [self.view addSubview:_scrollView];
    _scrollView.contentSize = CGSizeMake(4*scrollViewW, 0);
    for (NSInteger i=0; i<4; i++) {
        CGFloat viewX = i*scrollViewW;
        CGFloat viewY = 0;
        CGFloat viewW = scrollViewW;
        CGFloat viewH = scrollViewH;
        UIView *view = [[UIView alloc]initWithFrame:(CGRectMake(viewX, viewY, viewW, viewH))];
        [_scrollView addSubview:view];
        view.backgroundColor = self.colors[i];
    }
    NSLog(@"滚动视图的子视图%@",_scrollView.subviews);
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"滚动视图的子视图%@",_scrollView.subviews);
    });
}

#pragma mark - 触发方法
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"滚动视图的子视图%@",_scrollView.subviews);
}

- (IBAction)removeItem:(UIBarButtonItem *)sender {
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
}

- (IBAction)addItem:(UIBarButtonItem *)sender {
    _scrollView.showsHorizontalScrollIndicator = YES;
    _scrollView.showsVerticalScrollIndicator = YES;
}

#pragma mark - Get方法
- (NSArray *)colors {
	if(!_colors) {
		_colors = @[[UIColor redColor],[UIColor yellowColor],[UIColor blueColor],[UIColor greenColor]];
	}
	return _colors;
}

@end
